$(document).ready(function()
{

	$(".burger").click(function()
	{
        	$("#nav-div").slideToggle(300);
    	});
});

function clickEvent()
{
	document.getElementById("mappic").style.display = "block";
}	
